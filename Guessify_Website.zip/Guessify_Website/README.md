# Guessify — Number Guessing Game

A modern, responsive number guessing website for Cognifyz Technologies Level 1 Task 1, built with Python Flask, HTML, CSS, and JavaScript.

## Features
- Random number between 1 and 100
- Seven valid attempts
- High/low hints and clear game status
- Input validation
- Win and game-over messages
- Start a new round button
- Responsive desktop and mobile design

## Folder structure
```text
Guessify_Website/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── script.js
```

## Run on Windows
1. Extract the ZIP.
2. Open the `Guessify_Website` folder.
3. Click the File Explorer address bar, type `cmd`, and press Enter.
4. Install dependencies: `python -m pip install -r requirements.txt`
5. Start the app: `python app.py`
6. Open `http://127.0.0.1:5000` in your browser.
7. Keep the terminal open while playing. Press Ctrl+C in the terminal to stop the server.

This is a local learning project. Do not use Flask's development server for public production deployment.
