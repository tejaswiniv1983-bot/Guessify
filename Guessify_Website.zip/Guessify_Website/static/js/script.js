const form = document.getElementById("guess-form");
const input = document.getElementById("guess-input");
const guessButton = document.getElementById("guess-button");
const newGameButton = document.getElementById("new-game-button");
const attempts = document.getElementById("attempts-left");
const progress = document.getElementById("attempt-progress");
const feedback = document.getElementById("feedback");
const message = document.getElementById("feedback-message");

function showFeedback(text, type = "") {
  feedback.className = "feedback" + (type ? " " + type : "");
  message.textContent = text;
}
function updateAttempts(left) {
  attempts.textContent = left;
  progress.style.width = `${(left / 7) * 100}%`;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const raw = input.value.trim();
  if (!raw) {
    showFeedback("Please enter a number before guessing.", "error");
    input.focus();
    return;
  }
  const guess = Number(raw);
  if (!Number.isInteger(guess) || guess < 1 || guess > 100) {
    showFeedback("Enter a whole number from 1 to 100.", "error");
    input.focus();
    return;
  }
  guessButton.disabled = true;
  try {
    const response = await fetch("/guess", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({guess})
    });
    const result = await response.json();
    if (!response.ok) {
      showFeedback(result.message || "Please try again.", "error");
      return;
    }
    updateAttempts(result.attempts_left);
    showFeedback(result.message, result.won ? "success" : (result.game_over ? "error" : ""));
    if (result.game_over) {
      input.disabled = true;
      guessButton.disabled = true;
    } else {
      input.value = "";
      input.focus();
    }
  } catch {
    showFeedback("Could not contact the game server. Check the terminal and try again.", "error");
  } finally {
    if (!input.disabled) guessButton.disabled = false;
  }
});

newGameButton.addEventListener("click", async () => {
  newGameButton.disabled = true;
  try {
    const response = await fetch("/new-game", {method: "POST"});
    const result = await response.json();
    updateAttempts(result.attempts_left);
    input.disabled = false;
    guessButton.disabled = false;
    input.value = "";
    showFeedback(result.message, "success");
    input.focus();
  } catch {
    showFeedback("Could not start a new round. Refresh the page and try again.", "error");
  } finally {
    newGameButton.disabled = false;
  }
});
