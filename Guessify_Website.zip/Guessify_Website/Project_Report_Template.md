# Project Report: Guessify

**Internship:** Cognifyz Technologies  
**Task:** Level 1 — Task 1  
**Student name:** [Enter your name]  
**Date:** [Enter date]

## 1. Introduction
Guessify is a modern, browser-based number guessing game developed with Python Flask, HTML, CSS, and JavaScript. The computer selects a random number between 1 and 100, and the player tries to identify it within seven valid attempts.

## 2. Problem Statement
Beginners need practical exercises to understand conditional statements, input validation, and programming logic. Guessify offers an interactive game with high/low hints, attempt tracking, and a restart option.

## 3. Objectives
- Practice conditional statements and random number generation.
- Build a modern responsive web interface.
- Validate input and limit the number of attempts.
- Connect a website frontend to a Python Flask backend.

## 4. Technologies Used
Python, Flask, HTML, CSS, JavaScript.

## 5. Implementation
Flask creates the secret number and stores game progress in a session. JavaScript sends each guess to the `/guess` endpoint. Flask validates the guess, updates attempts, compares it to the secret number, and returns a hint or final result. The `/new-game` endpoint starts a fresh round.

## 6. Testing
Fill in the actual results after performing each test.

| Test | Expected result | Actual result |
|---|---|---|
| Guess lower than secret | Low hint | [Fill in] |
| Guess higher than secret | High hint | [Fill in] |
| Correct guess | Win message | [Fill in] |
| Seven incorrect valid guesses | Game-over message | [Fill in] |
| Empty or invalid input | Validation message | [Fill in] |
| Guess outside 1–100 | Validation message | [Fill in] |
| Start a new round | Attempts reset to 7 | [Fill in] |

## 7. Conclusion
Guessify demonstrates how a Python backend can power an interactive browser game. It provides hands-on practice with conditional logic, random numbers, validation, HTTP requests, and web development.

## 8. Screenshots
Add screenshots of the start screen, a high/low hint, a win or game-over result, and a restarted round.
